#include <cstdlib>
#include "GuessingGame.h"

GuessingGame::GuessingGame(int LargestPossibleTargetValue)
{
	// TODO:  Fill in as appropriate
	// NOTE:  Remember to use initialzier lists for all constructors
}

GuessingGame::GuessingGame(const GuessingGame& rhs)
{
	// TODO:  Fill in as appropriate
	// NOTE:  Remember to use initialzier lists for all constructors
}

GuessingGame& GuessingGame::operator=(const GuessingGame& rhs)
{
	// TODO:  Fill in as appropriate
	// NOTE:  What is "this" and why did I include this question here?
}

void GuessingGame::IncrementGuessCounter()
{
	// TODO:  Fill in as appropriate
}

int GuessingGame::GetGuessesMade() const
{
	// TODO:  Fill in as appropriate
}

bool operator <(int guess, const GuessingGame& game)
{
	// TODO:  Fill in as appropriate
}

bool operator >(int guess, const GuessingGame& game)
{
	// TODO:  Fill in as appropriate
}

bool operator !=(int guess, const GuessingGame& game)
{
	// TODO:  Fill in as appropriate
}