#include "Operand.h"

Operand::~Operand()
{
}

Number::Number(double v)
	: value(v)
{
}