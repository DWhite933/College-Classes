/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labch13;

/*
Name: David White
Class: CIS2571
Instructor: Barry Speller
Assignment: HW ch.13
File: Colorable.java
Description: Design an interface named Colorable with a void method named howToColor()
 */
public interface Colorable {
    //describes how to color the object
    public abstract String howToColor();
}
