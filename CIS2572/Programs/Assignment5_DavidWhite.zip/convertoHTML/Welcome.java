package chapter21;

// Name: David White
// Class: CIS2572
// Instructor:  Mohammad Morovati
// Assignment: Programming exercise 21.5
// File: Welcome.java
// Description: Test file

public class Welcome {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
